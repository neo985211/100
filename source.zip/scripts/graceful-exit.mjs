// Give Vite's native workers time to release Windows handles before CLI exit.
// Preserve every requested exit code, including failures.
if (process.platform === 'win32') {
  const exit = process.exit.bind(process);
  let pending = false;
  process.exit = (code = process.exitCode ?? 0) => {
    if (code !== 0 && code !== '0') return exit(code);
    if (!pending) {
      pending = true;
      setTimeout(() => exit(code), 1500);
    }
  };
}
