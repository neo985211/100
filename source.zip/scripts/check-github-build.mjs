import fs from 'node:fs';
import path from 'node:path';
const root = path.resolve('dist/github');
const html = fs.readFileSync(path.join(root,'index.html'),'utf8');
const base = process.env.NEXT_PUBLIC_BASE_PATH || '/100';
for (const [,url] of html.matchAll(/(?:src|href)="([^"]+)"/g)) {
  if (!url.startsWith(`${base}/`)) throw new Error(`Asset missing site prefix: ${url}`);
  if (!fs.existsSync(path.join(root,url.slice(base.length)))) throw new Error(`Asset not found: ${url}`);
}
const photos = fs.readdirSync(path.join(root,'photos')).filter(name=>name.endsWith('.jpg'));
if(photos.length!==71 || !photos.includes('32.1.jpg')) throw new Error('Incomplete photos');
if(!fs.existsSync(path.join(root,'.nojekyll'))) throw new Error('Missing .nojekyll');
console.log(`PASS: entry assets use ${base}/; all 71 photos and .nojekyll are present.`);
