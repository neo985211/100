# 第一百天，还是想选你

71 张照片、8 章回忆、逐章解锁、回忆问答、照片放大、轻音乐和结尾长信。

## 部署到 GitHub Pages

目标仓库：neo985211/100。
预期网站地址：https://neo985211.github.io/100/（须发布成功后才能访问）。

### 方式一：源码自动部署

1. 在 GitHub 创建 public 仓库 100，默认分支 main。
2. 将本项目的内容放在仓库根目录，包含 .github/workflows/pages.yml、package.json、app、public 等；不要把整个 memoir 文件夹再套在外面。
3. 仓库 Settings → Pages → Build and deployment → Source 选择 GitHub Actions。
4. 在 Actions 中运行 Publish our 100 days，或向 main 推送一次修改。
5. 流程成功后，打开 Pages 提供的链接即可分享。

工作流自动读取仓库网址的子路径，不需要把仓库名写死在照片路径里。
本项目没有服务器端接口、数据库、登录要求或远程图片依赖；网页互动全部在浏览器内运行。

### 方式二：直接上传已构建的静态网页

使用“100-静态网页.zip”。解压后把里面的 index.html、assets、photos、favicon.svg 和 .nojekyll 放在 100 仓库根目录。
在 Settings → Pages 将 Source 设为 Deploy from a branch，选择 main / (root) 并保存。
此包已经按 /100/ 构建，只适用于该路径；更改仓库名或使用自定义域名时需要重新构建。

### 本地构建

需要 Node.js 24 和 npm。

安装依赖：npm ci

PowerShell：

    $env:NEXT_PUBLIC_BASE_PATH = '/100'
    npm run build:github

macOS / Linux：

    NEXT_PUBLIC_BASE_PATH=/100 npm run build:github

构建输出：dist/github。发布时只需要该目录里的文件。
路径核对：node scripts/check-github-build.mjs（默认检查 /100，也可读取 NEXT_PUBLIC_BASE_PATH）。

## 修改回忆录

- 照片：public/photos，保留 1.jpg 至 70.jpg 和 32.1.jpg。
- 文案、章节和问题：app/memories.mjs。
- 页面、互动和结尾信：app/page.tsx。
- 样式：app/globals.css。
- GitHub 静态入口：index.html 和 app/github-entry.tsx。
- GitHub 构建配置：vite.github.config.ts。

阅读进度和收藏只保存在当前浏览器。换设备会从头开始。音乐需要点击后才播放，也可以随时关闭。
网页没有访问统计，不会上传阅读记录。
公开仓库中的源码和照片也会公开可见。

## 原有 Sites 版本

npm run dev 仍用于原项目的本地开发。npm run build 仍生成 Sites 用的 dist/client。
GitHub 使用独立的纯静态入口和 build:github，不依赖 Sites 的账号权限、托管配置或服务器运行环境。
