import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = { title: '第一百天，还是想选你 · 给宝宝的回忆录', description: '把我们的第一次，写成想和你过的一辈子。', robots: { index: false, follow: false } };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="zh-CN"><body>{children}</body></html>;
}
