// GitHub project sites live under /repository-name; Sites uses the root path.
export const assetPath = (path) => `${process.env.NEXT_PUBLIC_BASE_PATH || ''}${path}`;
