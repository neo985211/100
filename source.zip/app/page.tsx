'use client';
import { useEffect, useRef, useState } from 'react';
import { ArrowDown, ArrowLeft, ArrowRight, ArrowUpRight, Check, Heart, LockKeyhole, Maximize2, Music2, VolumeX, X, BookOpen, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogTitle, DialogDescription, DialogClose } from '@/components/ui/dialog';
import { chapters, memories } from './memories.mjs';
import { assetPath } from './asset-path.mjs';

type Progress = { chapter: number; unlocked: number; read: string[]; hearts: string[] };
const EMPTY: Progress = { chapter: 0, unlocked: 0, read: [], hearts: [] };
const STORAGE = 'our-little-forever-v1';
const num = (n: number) => String(n).padStart(2, '0');
const isIndex = (v: unknown, max: number): v is number => typeof v === 'number' && Number.isInteger(v) && v >= 0 && v <= max;
function loadProgress(): Progress {
  try {
    const p = JSON.parse(localStorage.getItem(STORAGE) || 'null');
    if (!p || !isIndex(p.unlocked,8) || !isIndex(p.chapter,7)) return EMPTY;
    const ids = new Set(memories.map(m=>m.id));
    return { chapter: Math.min(p.chapter,p.unlocked), unlocked:p.unlocked, read:Array.isArray(p.read)?[...new Set<string>(p.read.filter((id: unknown)=>typeof id==='string'&&ids.has(id)))]:[], hearts:Array.isArray(p.hearts)?[...new Set<string>(p.hearts.filter((id: unknown)=>typeof id==='string'&&ids.has(id)))]:[] };
  } catch { return EMPTY; }
}
function Photo({memory,index,onOpen,onHeart,loved}:{memory:(typeof memories)[number];index:number;onOpen:()=>void;onHeart:()=>void;loved:boolean}) {
  const [failed,setFailed]=useState(false);
  return <article className={`memory-card ${index%2?'reverse':''}`} data-memory-id={memory.id} id={`memory-${memory.id.replace('.','-')}`}>
    <div className="memory-visual"><button className="photo-button" onClick={onOpen} aria-label={`放大照片${memory.id}：${memory.title}`}>
      {failed?<span className="image-error">这张照片暂时没打开<br/>点一下，再看看它</span>:<img src={memory.src} alt={memory.title} loading="lazy" decoding="async" onError={()=>setFailed(true)}/>}
      <span className="zoom-label"><Maximize2 size={14}/> 看大一点</span>
    </button><div className="photo-footer"><span>OUR MEMORY · {memory.id}</span><span>♡</span></div></div>
    <div className="memory-copy"><span className="memory-index">{num(index+1)}<span> / 这一章的心动</span></span><h3>{memory.title}</h3><p>{memory.text}</p><button className={`keep-memory ${loved?'loved':''}`} onClick={onHeart} aria-pressed={loved}><Heart size={17} fill={loved?'currentColor':'none'}/>{loved?'这一刻，收好啦':'收下这一刻'}</button></div>
  </article>;
}
export default function Home() {
  const [progress,setProgress]=useState<Progress>(EMPTY);
  const [hydrated,setHydrated]=useState(false);
  const [started,setStarted]=useState(false);
  const [finale,setFinale]=useState(false);
  const [selected,setSelected]=useState<number|null>(null);
  const [solved,setSolved]=useState(false);
  const [mapOpen,setMapOpen]=useState(false);
  const [lightbox,setLightbox]=useState<string|null>(null);
  const [saidYes,setSaidYes]=useState(false);
  const [music,setMusic]=useState(false);
  const [audioError,setAudioError]=useState('');
  const [storageError,setStorageError]=useState(false);
  const audioRef=useRef<AudioContext|null>(null);
  const timerRef=useRef<ReturnType<typeof setInterval>|null>(null);
  const storyRef=useRef<HTMLElement|null>(null);
  const chapter=chapters[progress.chapter];
  const photos=memories.slice(chapter.range[0],chapter.range[1]);
  const readCount=photos.filter(m=>progress.read.includes(m.id)).length;
  const complete=readCount===photos.length;
  const already=progress.unlocked>progress.chapter;
  const openedPhoto=memories.find(m=>m.id===lightbox);
  useEffect(()=>{setProgress(loadProgress());setHydrated(true)},[]);
  useEffect(()=>{if(hydrated)try{localStorage.setItem(STORAGE,JSON.stringify(progress));setStorageError(false)}catch{setStorageError(true)}},[progress,hydrated]);
  useEffect(()=>{
    if(!started||finale)return;
    const observer=new IntersectionObserver(entries=>{
      const seen=entries.filter(e=>e.isIntersecting).map(e=>(e.target as HTMLElement).dataset.memoryId!).filter(Boolean);
      if(seen.length)setProgress(p=>seen.every(id=>p.read.includes(id))?p:{...p,read:[...new Set([...p.read,...seen])]});
    },{threshold:0.18});
    storyRef.current?.querySelectorAll('[data-memory-id]').forEach(el=>observer.observe(el));
    return ()=>observer.disconnect();
  },[started,finale,progress.chapter]);
  useEffect(()=>{setSelected(null);setSolved(false)},[progress.chapter]);
  useEffect(()=>()=>{if(timerRef.current)clearInterval(timerRef.current);void audioRef.current?.close()},[]);
  function scrollToStory(){setTimeout(()=>{const target=document.getElementById('story');target?.scrollIntoView({behavior:window.matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth'});target?.focus({preventScroll:true})},80)}
  function begin(){setStarted(true);setFinale(progress.unlocked===8);scrollToStory()}
  function goChapter(i:number){if(i>progress.unlocked)return;setProgress(p=>({...p,chapter:i}));setFinale(false);setMapOpen(false);setStarted(true);scrollToStory()}
  function nextChapter(){
    if(!already&&!solved)return;
    const next=progress.chapter+1;
    setProgress(p=>({...p,unlocked:Math.max(p.unlocked,next),chapter:Math.min(7,next)}));
    setSelected(null);setSolved(false);setFinale(next===8);scrollToStory();
  }
  function toggleHeart(id:string){setProgress(p=>({...p,hearts:p.hearts.includes(id)?p.hearts.filter(x=>x!==id):[...p.hearts,id]}))}
  function answer(i:number){setSelected(i);if(i===chapter.answer)setSolved(true)}
  async function toggleMusic(){
    if(music){if(timerRef.current)clearInterval(timerRef.current);timerRef.current=null;await audioRef.current?.suspend();setMusic(false);return}
    try{
      const ctx=audioRef.current??new AudioContext();audioRef.current=ctx;await ctx.resume();let step=0;
      const melody=[261.63,329.63,392,523.25,493.88,392,329.63,293.66,261.63,349.23,440,523.25,440,349.23,329.63,293.66];
      const play=()=>{if(document.hidden)return;const freq=melody[step%melody.length];[freq,freq/2].forEach((f,i)=>{const oscillator=ctx.createOscillator();const gain=ctx.createGain();oscillator.type='sine';oscillator.frequency.value=f;gain.gain.setValueAtTime(0,ctx.currentTime);gain.gain.linearRampToValueAtTime(i?0.016:0.045,ctx.currentTime+.025);gain.gain.exponentialRampToValueAtTime(.0001,ctx.currentTime+2.8);oscillator.connect(gain);gain.connect(ctx.destination);oscillator.start();oscillator.stop(ctx.currentTime+3);oscillator.onended=()=>{oscillator.disconnect();gain.disconnect()}});step++};
      play();timerRef.current=setInterval(play,850);setMusic(true);setAudioError('');
    }catch{setAudioError('这次音乐没能响起来，先静静看我们的故事吧。')}
  }
  return <main>
    <header className="topbar"><a className="brand" href="#" onClick={e=>{e.preventDefault();window.scrollTo({top:0,behavior:'smooth'})}}>100<span>OUR LITTLE FOREVER</span></a><span className="dedication">只写给你 · 也只关于我们</span><button className={`music-button ${music?'playing':''}`} onClick={toggleMusic} aria-pressed={music} aria-label={music?'关闭音乐':'播放轻柔音乐'}>{music?<Music2 size={17}/>:<VolumeX size={17}/>}<span>{music?'音乐轻轻响':'听一点音乐'}</span></button></header>
    {audioError&&<p className="notice" role="status">{audioError}</p>}
    <section className="cover">
      <div className="cover-copy"><p className="eyebrow">A LOVE LETTER, IN 71 FRAMES</p><h1>第一百天，<br/>还是想<span className="italic">选你。</span></h1><p className="intro">宝宝，借我一点时间。<br/>陪我把我们的故事，再心动一次。</p><Button className="primary" onClick={begin} disabled={!hydrated}>{progress.read.length?(progress.unlocked===8?'再读一次，写给你的信':'接着上次的心动'):'从那阵海风开始'} <ArrowUpRight size={19}/></Button><div className="cover-meta"><span>71 张照片</span><i/><span>8 章心动</span><i/><span>还有很长的以后</span></div>{progress.read.length>0&&<button className="cover-continue" onClick={()=>{setStarted(true);setMapOpen(true)}}>已经重温 {progress.read.length} / 71 个瞬间 · 翻看目录</button>}</div>
      <div className="cover-art"><div className="cover-outline"/><figure className="hero-photo"><img src={assetPath('/photos/18.jpg')} alt="我们第一次正式的情侣合照" fetchPriority="high"/><figcaption><span>你看，是我们欸。</span><Heart size={17}/></figcaption></figure><div className="little-photo"><img src={assetPath('/photos/9.jpg')} alt="开满花的副驾驶"/><span>喜欢，是藏不住的。</span></div><span className="photo-note">所有平凡，都因为你有了意义。</span><span className="floating-number" aria-hidden="true">100</span></div>
      <div className="cover-bottom"><span>从没说出口的喜欢，到想和你过的一辈子。</span><ArrowDown size={16}/><span>SCROLL TO REMEMBER</span></div>
    </section>
    {started&&<>
      <nav className="journey-nav" aria-label="阅读进度"><button onClick={()=>setMapOpen(true)}><BookOpen size={17}/><span>我们的八章</span></button><div className="journey-dots">{chapters.map((c,i)=><button key={c.word} disabled={i>progress.unlocked} onClick={()=>goChapter(i)} aria-label={`第${i+1}章：${c.title}${i>progress.unlocked?'，尚未解锁':''}`} aria-current={!finale&&i===progress.chapter?'step':undefined} className={`${i<progress.unlocked?'done':''} ${!finale&&i===progress.chapter?'current':''}`}>{i<progress.unlocked?<Check size={11}/>:i+1}</button>)}</div><span className="journey-count">{progress.read.length}<span> / 71 瞬间</span></span></nav>
      {storageError&&<p className="notice" role="status">当前浏览器暂时无法保存进度，留在这一页可以继续阅读。</p>}
      {!finale?<section id="story" ref={storyRef} tabIndex={-1} className="chapter-section" key={progress.chapter}>
        <header className="chapter-heading"><p className="eyebrow">CHAPTER {num(progress.chapter+1)} / 08</p><div className="chapter-number" aria-hidden="true">{num(progress.chapter+1)}</div><h2>{chapter.title}</h2><p>{chapter.subtitle}</p><span className="chapter-instruction">慢慢往下翻，都是我舍不得忘记的瞬间 <ArrowDown size={14}/></span></header>
        <div className="memory-list">{photos.map((m,i)=><Photo key={m.id} memory={m} index={i} loved={progress.hearts.includes(m.id)} onHeart={()=>toggleHeart(m.id)} onOpen={()=>setLightbox(m.id)}/>)}</div>
        <section className="chapter-gate" aria-labelledby="gate-title"><p className="eyebrow">A LITTLE MEMORY, A LITTLE PROMISE</p><Heart className="gate-heart" size={25}/><h3 id="gate-title">这一章，还有一句话想给你。</h3>{complete||already?<>
          {!solved&&!already?<><p className="question">{chapter.question}</p><div className="answer-options">{chapter.options.map((option,i)=><Button key={option} className={`answer ${selected===i?'picked':''}`} onClick={()=>answer(i)}><span>{String.fromCharCode(65+i)}</span>{option}<ArrowUpRight size={16}/></Button>)}</div><p className="answer-hint" aria-live="polite">{selected!==null?'没关系，忘掉的小细节，我替你记着。再猜一次？':'没有考试，只有我们一起记得的小事。'}</p><button className="text-button" onClick={()=>setSolved(true)}>不记得也没关系，听你告诉我</button></>:<div className="promise-reveal" aria-live="polite"><span className="promise-seal">{chapter.word}</span><p>{chapter.reply}</p><blockquote>{chapter.promise}</blockquote><Button className="primary" onClick={nextChapter}>{progress.chapter===7?'拆开最后一封信':'收好这句话，翻开下一章'} <ArrowRight size={18}/></Button></div>}
        </>:<div className="unread-note"><p>还有 {photos.length-readCount} 个瞬间，等你慢慢翻到。</p><Button className="primary" onClick={()=>{const first=photos.find(m=>!progress.read.includes(m.id));document.getElementById(`memory-${first?.id.replace('.','-')}`)?.scrollIntoView({behavior:'smooth',block:'center'})}}>回到没看过的那一张 <ArrowUpRight size={17}/></Button></div>}
        <div className="chapter-endnote">{num(progress.chapter+1)} / 08 · 每翻过一章，离我们的以后再近一点。</div></section>
      </section>:<section id="story" tabIndex={-1} className="finale">
        <div className="finale-heading"><p className="eyebrow">THE FIRST 100 DAYS. THE REST OF OUR LIVES.</p><span className="hundred">100<span>天</span></span><h2>故事到这里，<br/>我们才刚刚开始。</h2><p>八章回忆，八句想认真做到的承诺。</p><div className="collected-words">{chapters.map(c=><span key={c.word} title={c.promise}>{c.word}</span>)}</div></div>
        <article className="love-letter"><div className="letter-top"><span>TO MY FAVORITE PERSON</span><Heart size={20}/></div><h3>亲爱的宝宝：</h3><p>翻完这些照片，我才发现，原来我们已经一起拥有了这么多个第一次。</p><p>第一次吹深圳湾的海风，第一次单独吃火锅，第一次把没敢说出口的喜欢变成一车的花。第一次靠在肩上，第一次给你吹头发，第一次为你做饭，也第一次，被你这样认真地庆祝生日。</p><p>从前我以为，喜欢一个人，是要准备一场很盛大的表白。后来和你在一起才知道，它也可以很小：是记住你爱酸酸甜甜、爱鱿鱼须，是惦记着一直没吃到的鹅肠，是你说一句好吃，我就想再给你做很多顿饭。</p><p>是你睡着的时候，我想让你再舒服一点。是分开的时候，把每一次视频截图都保存下来。是一件你穿过的衣服，我也觉得格外好闻。</p><p>而你，也一直在用你的方式爱我。你主动给我勇气，你补上表白的蛋糕，把“第一位”留给我。你记得我的喜欢，替我实现小时候的梦想。那个想把你宠成小朋友的人，也被你温柔地宠了一次。</p><p className="letter-emphasis">宝宝，谢谢你让我知道，<br/>原来我也值得被这样认真地爱着。</p><p>这一百天，有惊喜，也有没吃好的饭、没买中的彩票，有准备生日时的坎坷，也有不得不分开的日子。它们没有每一刻都完美。可因为同行的人是你，再回头看，我还是一刻也舍不得删掉。</p><p>那天在深圳湾，我们聊起三十岁的未来。现在，我想把这个约定再说得认真一点：三十岁的时候，我还想站在你身边。也想陪你走到更远，走到照片里的我们慢慢变了模样，还能笑着说起今天。</p><p>以后，我们还会有好多第一次。也许会一起养一只小狗，也许会找到更好吃的小店，会去新的海边，会把做饭、吹头发、等对方回家这些小事，做过一遍又一遍。</p><p>我知道，一辈子不是写在这里就算数的。它要我在往后的每一天，都认真地爱你、照顾你，好好听你说话，好好走到你身边。</p><p className="letter-emphasis">所以，这不是第一百天的结尾。<br/>这是我写给我们的，第一百天的开头。</p><p>照片暂时停在这里，喜欢不会。下一个一百天，下下个一百天，还有好多好多年——我都想和你一起。</p><div className="letter-sign"><span>永远想给你做好吃的饭、<br/>想给你吹头发的我</span><Heart size={22}/></div></article>
        <div className="future"><p className="eyebrow">TO BE CONTINUED, WITH YOU</p><h3>{saidYes?'那就说好啦。':'下一页，还是我们，好不好？'}</h3>{saidYes?<div className="future-answer" aria-live="polite"><Sparkles size={28}/><p>第 101 天，还有以后的每一天。<br/>宝宝，我们慢慢来，来日方长。</p><span>100 → ∞</span></div>:<Button className="primary" onClick={()=>setSaidYes(true)}>好，我们一起写下去 <Heart size={18}/></Button>}<button className="text-button replay" onClick={()=>goChapter(0)}><ArrowLeft size={15}/> 再从第一张，看看我们</button></div>
        <div className="closing-film" aria-label="我们的回忆剪影">{['1','9','18','28','33','41','53','65','70'].map(id=><button key={id} onClick={()=>setLightbox(id)} aria-label={`重看照片${id}`}><img src={assetPath(`/photos/${id}.jpg`)} alt={memories.find(m=>m.id===id)?.title} loading="lazy"/></button>)}</div><footer className="final-footer">第一百天，还是想选你。<span>WITH YOU, ALWAYS.</span></footer>
      </section>}
    </>}
    <Dialog open={mapOpen} onOpenChange={setMapOpen}><DialogContent className="chapter-dialog" showCloseButton={false}><div className="modal-heading"><div><DialogTitle>我们的故事目录</DialogTitle><DialogDescription>一章一章，把那时的心动找回来。</DialogDescription></div><DialogClose className="icon-button" aria-label="关闭目录"><X size={20}/></DialogClose></div><div className="chapter-menu">{chapters.map((c,i)=><button key={c.word} onClick={()=>goChapter(i)} disabled={i>progress.unlocked}><span className="menu-number">{num(i+1)}</span><span><strong>{c.title}</strong><small>{i<progress.unlocked?`已收好 · ${c.word}`:i===progress.unlocked?'等你翻开':'读完前一章，就会打开'}</small></span>{i>progress.unlocked?<LockKeyhole size={16}/>:<ArrowUpRight size={19}/>}</button>)}</div>{progress.unlocked===8&&<Button className="primary" onClick={()=>{setFinale(true);setStarted(true);setMapOpen(false);scrollToStory()}}>重读写给你的信 <Heart size={16}/></Button>}<p className="map-footnote">{progress.read.length} 个瞬间已重温 · {progress.hearts.length} 个心动已收好</p></DialogContent></Dialog>
    <Dialog open={lightbox!==null} onOpenChange={open=>{if(!open)setLightbox(null)}}><DialogContent className="lightbox" showCloseButton={false}><DialogTitle className="sr-only">{openedPhoto?.title||'我们的照片'}</DialogTitle><DialogDescription className="sr-only">照片{openedPhoto?.id}的完整画面</DialogDescription><DialogClose className="lightbox-close icon-button" aria-label="关闭照片"><X size={22}/></DialogClose>{openedPhoto&&<img src={openedPhoto.src} alt={openedPhoto.title}/>}<p>{openedPhoto?.title}</p></DialogContent></Dialog>
  </main>;
}

